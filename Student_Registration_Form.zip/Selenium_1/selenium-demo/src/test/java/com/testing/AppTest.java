package com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AppTest {
    @Test
    public void studentNameTest() throws InterruptedException {
        WebDriver driver = new ChromeDriver();

        driver.get("file:///C:/software%20testing/test.html");


        

        driver.findElement(By.id("registerBtn")).click();

        Thread.sleep(3000);
        String value = driver.findElement(By.id("message")).getText();
        Assert.assertEquals(value, "Student name is required");

        driver.quit();
    }

    @Test
    public void emailTest() throws InterruptedException{
        WebDriver driver = new ChromeDriver();
        driver.get("file:///C:/software%20testing/test.html");

        driver.findElement(By.id("studentName")).sendKeys("Abc");
        driver.findElement(By.id("registerBtn")).click();
        
        Thread.sleep(3000);
        String value = driver.findElement(By.id("message")).getText();
        Assert.assertEquals(value, "Email is required");

        driver.quit();
    }

    @Test
    public void invalidemailTest() throws InterruptedException{
        WebDriver driver = new ChromeDriver();
        driver.get("file:///C:/software%20testing/test.html");

        driver.findElement(By.id("studentName")).sendKeys("Abc");
        driver.findElement(By.id("email")).sendKeys("abc");
        driver.findElement(By.id("registerBtn")).click();
        
        Thread.sleep(3000);
        String value = driver.findElement(By.id("message")).getText();
        Assert.assertEquals(value, "Invalid email format");

        driver.quit();
    }    

    @Test
    public void mobilenumber() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("file:///C:/software%20testing/test.html");

        driver.findElement(By.id("studentName")).sendKeys("Abc");
        driver.findElement(By.id("email")).sendKeys("abc@gmail.com");
        driver.findElement(By.id("mobile")).sendKeys("12345678");
        driver.findElement(By.id("registerBtn")).click();

        Thread.sleep(3000);
        String value = driver.findElement(By.id("message")).getText();
        Assert.assertEquals(value, "Mobile number should be exactly 10 digits");

        driver.quit();
    }
    @Test
    public void gender() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("file:///C:/software%20testing/test.html");

        driver.findElement(By.id("studentName")).sendKeys("Abc");
        driver.findElement(By.id("email")).sendKeys("abc@gmail.com");
        driver.findElement(By.id("mobile")).sendKeys("1234567890");
        driver.findElement(By.id("registerBtn")).click();

        Thread.sleep(3000);
        String value = driver.findElement(By.id("message")).getText();
        Assert.assertEquals(value, "Gender is required");

        driver.quit();
    }

    @Test
    public void departmentTest() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("file:///C:/software%20testing/test.html");

        driver.findElement(By.id("studentName")).sendKeys("Abc");
        driver.findElement(By.id("email")).sendKeys("abc@gmail.com");
        driver.findElement(By.id("mobile")).sendKeys("1234567890");
        driver.findElement(By.id("male")).click();
        driver.findElement(By.id("registerBtn")).click();

        Thread.sleep(3000);
        String value = driver.findElement(By.id("message")).getText();
        Assert.assertEquals(value, "Department is required");

        driver.quit();
    }  

    @Test
    public void Invalidpassword() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("file:///C:/software%20testing/test.html");

        driver.findElement(By.id("studentName")).sendKeys("Abc");
        driver.findElement(By.id("email")).sendKeys("abc@gmail.com");
        driver.findElement(By.id("mobile")).sendKeys("1234567890");
        driver.findElement(By.id("male")).click();
        driver.findElement(By.id("password")).sendKeys("123");
        driver.findElement(By.id("department"));
        new Select(driver.findElement(By.id("department"))).selectByValue("CSE");
        driver.findElement(By.id("registerBtn")).click();

        Thread.sleep(3000);
        String value = driver.findElement(By.id("message")).getText();
        Assert.assertEquals(value, "Password should be minimum 8 characters");

        driver.quit();
    }  

    @Test
    public void confirmpassword() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("file:///C:/software%20testing/test.html");

        driver.findElement(By.id("studentName")).sendKeys("Abc");
        driver.findElement(By.id("email")).sendKeys("abc@gmail.com");
        driver.findElement(By.id("mobile")).sendKeys("1234567890");
        driver.findElement(By.id("male")).click();
        driver.findElement(By.id("department"));
        new Select(driver.findElement(By.id("department"))).selectByValue("CSE");
        driver.findElement(By.id("password")).sendKeys("12345678");
        driver.findElement(By.id("confirmPassword")).sendKeys("87654321");
        driver.findElement(By.id("registerBtn")).click();

        Thread.sleep(3000);
        String value = driver.findElement(By.id("message")).getText();
        Assert.assertEquals(value, "Password and confirm password should match");

        driver.quit();
    } 

    @Test
    public void termsandconditions() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("file:///C:/software%20testing/test.html");

        driver.findElement(By.id("studentName")).sendKeys("Abc");
        driver.findElement(By.id("email")).sendKeys("abc@gmail.com");
        driver.findElement(By.id("mobile")).sendKeys("1234567890");
        driver.findElement(By.id("male")).click();
        driver.findElement(By.id("department"));
        new Select(driver.findElement(By.id("department"))).selectByValue("CSE");
        driver.findElement(By.id("password")).sendKeys("12345678");
        driver.findElement(By.id("confirmPassword")).sendKeys("12345678");
        driver.findElement(By.id("registerBtn")).click();

        Thread.sleep(3000);
        String value = driver.findElement(By.id("message")).getText();
        Assert.assertEquals(value, "Please accept terms and conditions");

        driver.quit();
    } 

     @Test
    public void registration() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("file:///C:/software%20testing/test.html");

        driver.findElement(By.id("studentName")).sendKeys("Abc");
        driver.findElement(By.id("email")).sendKeys("abc@gmail.com");
        driver.findElement(By.id("mobile")).sendKeys("1234567890");
        driver.findElement(By.id("male")).click();
        driver.findElement(By.id("department"));
        new Select(driver.findElement(By.id("department"))).selectByValue("CSE");
        driver.findElement(By.id("password")).sendKeys("12345678");
        driver.findElement(By.id("confirmPassword")).sendKeys("12345678");
        driver.findElement(By.id("terms")).click();
        driver.findElement(By.id("registerBtn")).click();

        Thread.sleep(3000);
        String value = driver.findElement(By.id("message")).getText();
        Assert.assertEquals(value, "Registration successful");

        driver.quit();
    } 
    
    



}